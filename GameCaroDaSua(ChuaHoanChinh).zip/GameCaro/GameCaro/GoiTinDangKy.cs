﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameCaro
{
    public class GoiTinDangKy
    {
        public string HoVaTen { get; set; }
        public string TenTaiKhoan { get; set; }
        public string Gmail { get; set; }
        public string MatKhau { get; set; }
    }
}
