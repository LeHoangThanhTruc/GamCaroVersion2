﻿namespace GameCaro
{
    partial class CaiDat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkBoxAmNhac = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.linkLabelChangeHoVaTen = new System.Windows.Forms.LinkLabel();
            this.linkLabelChangeGmail = new System.Windows.Forms.LinkLabel();
            this.linkLabelChangeTenTaiKhoan = new System.Windows.Forms.LinkLabel();
            this.linkLabelChangeMatKhau = new System.Windows.Forms.LinkLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnQuayLaiGiaoDienChung = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // checkBoxAmNhac
            // 
            this.checkBoxAmNhac.AutoSize = true;
            this.checkBoxAmNhac.Font = new System.Drawing.Font("Cambria", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxAmNhac.Location = new System.Drawing.Point(23, 89);
            this.checkBoxAmNhac.Name = "checkBoxAmNhac";
            this.checkBoxAmNhac.Size = new System.Drawing.Size(116, 29);
            this.checkBoxAmNhac.TabIndex = 0;
            this.checkBoxAmNhac.Text = "Âm nhạc";
            this.checkBoxAmNhac.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.linkLabelChangeMatKhau);
            this.panel1.Controls.Add(this.linkLabelChangeTenTaiKhoan);
            this.panel1.Controls.Add(this.linkLabelChangeGmail);
            this.panel1.Controls.Add(this.linkLabelChangeHoVaTen);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(23, 161);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(269, 202);
            this.panel1.TabIndex = 3;
            // 
            // linkLabelChangeHoVaTen
            // 
            this.linkLabelChangeHoVaTen.AutoSize = true;
            this.linkLabelChangeHoVaTen.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelChangeHoVaTen.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabelChangeHoVaTen.LinkColor = System.Drawing.Color.Black;
            this.linkLabelChangeHoVaTen.Location = new System.Drawing.Point(3, 19);
            this.linkLabelChangeHoVaTen.Name = "linkLabelChangeHoVaTen";
            this.linkLabelChangeHoVaTen.Size = new System.Drawing.Size(211, 28);
            this.linkLabelChangeHoVaTen.TabIndex = 0;
            this.linkLabelChangeHoVaTen.TabStop = true;
            this.linkLabelChangeHoVaTen.Text = "Thay đổi họ và tên";
            this.linkLabelChangeHoVaTen.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // linkLabelChangeGmail
            // 
            this.linkLabelChangeGmail.AutoSize = true;
            this.linkLabelChangeGmail.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelChangeGmail.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabelChangeGmail.LinkColor = System.Drawing.Color.Black;
            this.linkLabelChangeGmail.Location = new System.Drawing.Point(3, 108);
            this.linkLabelChangeGmail.Name = "linkLabelChangeGmail";
            this.linkLabelChangeGmail.Size = new System.Drawing.Size(177, 28);
            this.linkLabelChangeGmail.TabIndex = 1;
            this.linkLabelChangeGmail.TabStop = true;
            this.linkLabelChangeGmail.Text = "Thay đổi Gmail";
            this.linkLabelChangeGmail.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // linkLabelChangeTenTaiKhoan
            // 
            this.linkLabelChangeTenTaiKhoan.AutoSize = true;
            this.linkLabelChangeTenTaiKhoan.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelChangeTenTaiKhoan.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabelChangeTenTaiKhoan.LinkColor = System.Drawing.Color.Black;
            this.linkLabelChangeTenTaiKhoan.Location = new System.Drawing.Point(3, 64);
            this.linkLabelChangeTenTaiKhoan.Name = "linkLabelChangeTenTaiKhoan";
            this.linkLabelChangeTenTaiKhoan.Size = new System.Drawing.Size(257, 28);
            this.linkLabelChangeTenTaiKhoan.TabIndex = 2;
            this.linkLabelChangeTenTaiKhoan.TabStop = true;
            this.linkLabelChangeTenTaiKhoan.Text = "Thay đổi tên tài khoản";
            this.linkLabelChangeTenTaiKhoan.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // linkLabelChangeMatKhau
            // 
            this.linkLabelChangeMatKhau.AutoSize = true;
            this.linkLabelChangeMatKhau.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelChangeMatKhau.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabelChangeMatKhau.LinkColor = System.Drawing.Color.Black;
            this.linkLabelChangeMatKhau.Location = new System.Drawing.Point(3, 149);
            this.linkLabelChangeMatKhau.Name = "linkLabelChangeMatKhau";
            this.linkLabelChangeMatKhau.Size = new System.Drawing.Size(215, 28);
            this.linkLabelChangeMatKhau.TabIndex = 3;
            this.linkLabelChangeMatKhau.TabStop = true;
            this.linkLabelChangeMatKhau.Text = "Thay đổi mật khẩu";
            this.linkLabelChangeMatKhau.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cambria", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(18, 133);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(305, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "Thay đổi thông tin người chơi";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Ravie", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(81, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(259, 63);
            this.label2.TabIndex = 5;
            this.label2.Text = "Cài Đặt";
            // 
            // btnQuayLaiGiaoDienChung
            // 
            this.btnQuayLaiGiaoDienChung.Location = new System.Drawing.Point(310, 379);
            this.btnQuayLaiGiaoDienChung.Name = "btnQuayLaiGiaoDienChung";
            this.btnQuayLaiGiaoDienChung.Size = new System.Drawing.Size(75, 23);
            this.btnQuayLaiGiaoDienChung.TabIndex = 6;
            this.btnQuayLaiGiaoDienChung.Text = "Quay Lại";
            this.btnQuayLaiGiaoDienChung.UseVisualStyleBackColor = true;
            this.btnQuayLaiGiaoDienChung.Click += new System.EventHandler(this.btnQuayLaiGiaoDienChung_Click);
            // 
            // CaiDat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(388, 405);
            this.Controls.Add(this.btnQuayLaiGiaoDienChung);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.checkBoxAmNhac);
            this.Name = "CaiDat";
            this.Text = "Game Caro";
            this.Load += new System.EventHandler(this.CaiDat_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox checkBoxAmNhac;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.LinkLabel linkLabelChangeTenTaiKhoan;
        private System.Windows.Forms.LinkLabel linkLabelChangeGmail;
        private System.Windows.Forms.LinkLabel linkLabelChangeHoVaTen;
        private System.Windows.Forms.LinkLabel linkLabelChangeMatKhau;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnQuayLaiGiaoDienChung;
    }
}